To run all the performance overhead measurements, run the run.py script as :
python run.py

The script will compile all source files and run multiple iterations of each test. 
The input arguments taken by each test are passed via the python script.
The results from each test will be put in a seprate tab in an Excel sheet named "readings.xls".

Following dependencies (modules) should be installed to run the python script:
subprocess
shlex
xlwt
math
statistics
